// Mobile menu toggle
const menuBtn = document.getElementById("menu-btn");
const mobileMenu = document.getElementById("mobile-menu");

menuBtn.addEventListener("click", () => {
  mobileMenu.classList.toggle("hidden");
});

// Form validation and success message
const form = document.getElementById("contact-form");
const formSuccess = document.getElementById("form-success");

form.addEventListener("submit", (e) => {
  e.preventDefault();

  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const message = document.getElementById("message").value.trim();

  if (name === "" || email === "" || message === "") {
    alert("Please fill in all fields!");
    return;
  }

  // Simple email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    alert("Please enter a valid email!");
    return;
  }

  // Show success message
  formSuccess.classList.remove("hidden");

  // Clear form
  form.reset();

  // Hide message after 3 seconds
  setTimeout(() => {
    formSuccess.classList.add("hidden");
  }, 3000);
});
